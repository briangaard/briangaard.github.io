import Link from "next/link";
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-1">
            <Link href="/" className="mb-6 block">
              <span className="font-headline font-bold text-2xl tracking-tighter">
                KIRI<span className="text-secondary">ELECTRICS</span>
              </span>
            </Link>
            <p className="text-primary-foreground/70 mb-6 leading-relaxed">
              Premium electrical engineering and maintenance for high-demand environments. Safety, precision, and performance.
            </p>
            <div className="flex gap-4">
              <Facebook className="w-5 h-5 cursor-pointer hover:text-secondary" />
              <Instagram className="w-5 h-5 cursor-pointer hover:text-secondary" />
              <Linkedin className="w-5 h-5 cursor-pointer hover:text-secondary" />
            </div>
          </div>

          <div>
            <h4 className="font-headline font-bold text-lg mb-6 text-secondary">Sitemap</h4>
            <ul className="space-y-4 text-primary-foreground/70">
              <li><Link href="/" className="hover:text-secondary transition-colors">Home</Link></li>
              <li><Link href="/services" className="hover:text-secondary transition-colors">Services</Link></li>
              <li><Link href="/about" className="hover:text-secondary transition-colors">Our Story</Link></li>
              <li><Link href="/contact" className="hover:text-secondary transition-colors">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-headline font-bold text-lg mb-6 text-secondary">Expertise</h4>
            <ul className="space-y-4 text-primary-foreground/70">
              <li className="hover:text-secondary cursor-pointer">Industrial Wiring</li>
              <li className="hover:text-secondary cursor-pointer">Commercial Fit-outs</li>
              <li className="hover:text-secondary cursor-pointer">Critical Power Repairs</li>
              <li className="hover:text-secondary cursor-pointer">EV Infrastructure</li>
            </ul>
          </div>

          <div>
            <h4 className="font-headline font-bold text-lg mb-6 text-secondary">Contact</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 text-primary-foreground/70">
                <Phone className="w-4 h-4 text-secondary" /> (555) 999-0000
              </li>
              <li className="flex items-center gap-3 text-primary-foreground/70">
                <Mail className="w-4 h-4 text-secondary" /> support@kirielectrics.com
              </li>
              <li className="flex items-start gap-3 text-primary-foreground/70">
                <MapPin className="w-4 h-4 text-secondary mt-1" /> 88 Volt Highway, Circuit City, ST
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-primary-foreground/10 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-primary-foreground/40 gap-4 text-center">
          <p>© {new Date().getFullYear()} KiriElectrics Industrial. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="#">Privacy</Link>
            <Link href="#">Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}