
"use client";

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { aiCustomerServiceRecommender, type ServiceRecommenderOutput } from "@/ai/flows/ai-customer-service-recommender";
import { Sparkles, Send, Bot, User, RefreshCcw } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { LeadPopup } from "./LeadPopup";

export function AIRecommender() {
  const [query, setQuery] = useState("");
  const [history, setHistory] = useState<{ role: 'user' | 'model', text: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<ServiceRecommenderOutput | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || loading) return;

    const currentQuery = query;
    setQuery("");
    const newHistory = [...history, { role: 'user' as const, text: currentQuery }];
    setHistory(newHistory);
    setLoading(true);

    try {
      const result = await aiCustomerServiceRecommender({
        conversationHistory: history,
        currentQuery: currentQuery
      });
      setHistory([...newHistory, { role: 'model' as const, text: result.response }]);
      setRecommendation(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setHistory([]);
    setRecommendation(null);
    setQuery("");
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [history]);

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-xl border-t-4 border-t-secondary overflow-hidden">
      <CardHeader className="bg-primary/5">
        <div className="flex items-center gap-2 mb-2">
          <div className="bg-secondary p-1.5 rounded-full">
            <Sparkles className="w-4 h-4 text-secondary-foreground" />
          </div>
          <CardTitle className="text-xl font-headline">AI Service Advisor</CardTitle>
        </div>
        <CardDescription>
          Not sure what you need? Describe your situation and let our AI guide you.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px] p-4">
          <div className="space-y-4">
            {history.length === 0 && (
              <div className="text-center py-10 text-muted-foreground">
                <Bot className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p>Hello! I'm Volt, your expert assistant.<br />How can I help you today?</p>
              </div>
            )}
            {history.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`flex gap-2 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}`}>
                    {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                  </div>
                  <div className={`rounded-2xl px-4 py-2 text-sm shadow-sm ${msg.role === 'user' ? 'bg-primary text-primary-foreground rounded-tr-none' : 'bg-accent text-accent-foreground rounded-tl-none'}`}>
                    {msg.text}
                  </div>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="flex gap-2 items-center bg-accent rounded-full px-4 py-2 text-sm animate-pulse">
                  <RefreshCcw className="w-3 h-3 animate-spin" /> Volt is thinking...
                </div>
              </div>
            )}
            {recommendation?.isFinalRecommendation && (
              <div className="animate-fade-in p-6 bg-secondary/10 border-2 border-secondary/20 rounded-xl mt-4">
                <h4 className="font-bold text-primary mb-2 flex items-center gap-2">
                  <Sparkles className="w-4 h-4" /> Recommended Action:
                </h4>
                <p className="text-sm font-semibold text-primary/80 mb-4">{recommendation.recommendedServiceCategory}</p>
                <LeadPopup>
                  <Button className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90">
                    Book This Service Now
                  </Button>
                </LeadPopup>
                <Button variant="ghost" size="sm" onClick={reset} className="w-full mt-2 text-xs opacity-50">
                  Start Over
                </Button>
              </div>
            )}
            <div ref={scrollRef} />
          </div>
        </ScrollArea>

        {!recommendation?.isFinalRecommendation && (
          <form onSubmit={handleSend} className="p-4 border-t flex gap-2">
            <Input 
              placeholder="e.g. My lights are flickering in the kitchen..." 
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              disabled={loading}
              className="flex-1"
            />
            <Button type="submit" disabled={loading} size="icon" className="bg-primary hover:bg-primary/90">
              <Send className="w-4 h-4" />
            </Button>
          </form>
        )}
      </CardContent>
    </Card>
  );
}
