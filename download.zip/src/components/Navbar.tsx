"use client";

import Link from "next/link";
import { Menu, X, Phone } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { LeadPopup } from "./LeadPopup";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-white/10 bg-primary text-white backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center group">
          <span className="font-headline font-bold text-2xl tracking-tighter uppercase">
            KIRI<span className="text-secondary ml-1">ELECTRICS</span>
          </span>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          <div className="flex items-center gap-6 mr-4 border-r border-white/10 pr-6">
            <Link href="/" className="text-xs font-bold hover:text-secondary transition-colors uppercase tracking-widest">Home</Link>
            <Link href="/services" className="text-xs font-medium hover:text-secondary transition-colors uppercase tracking-widest">Capabilities</Link>
            <Link href="/about" className="text-xs font-medium hover:text-secondary transition-colors uppercase tracking-widest">Mission</Link>
            <Link href="/contact" className="text-xs font-medium hover:text-secondary transition-colors uppercase tracking-widest">Contact</Link>
          </div>
          
          <a href="tel:5559990000" className="flex items-center gap-2 text-sm font-black text-secondary hover:text-white transition-colors">
            <Phone className="w-4 h-4" /> (555) 999-0000
          </a>

          <LeadPopup>
            <Button className="bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold shadow-sm rounded-none px-6 text-xs uppercase tracking-widest">
              BOOK AUDIT
            </Button>
          </LeadPopup>
        </div>

        {/* Mobile Menu Toggle */}
        <button onClick={() => setIsOpen(!isOpen)} className="md:hidden p-2 text-white">
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-16 left-0 w-full bg-primary border-b border-white/10 animate-in slide-in-from-top duration-300">
          <div className="flex flex-col p-4 gap-4">
            <Link href="/" onClick={() => setIsOpen(false)} className="text-lg font-bold p-2 text-white">Home</Link>
            <Link href="/services" onClick={() => setIsOpen(false)} className="text-lg font-medium p-2 text-white/70">Capabilities</Link>
            <Link href="/about" onClick={() => setIsOpen(false)} className="text-lg font-medium p-2 text-white/70">Mission</Link>
            <Link href="/contact" onClick={() => setIsOpen(false)} className="text-lg font-medium p-2 text-white/70">Contact</Link>
            <a href="tel:5559990000" className="flex items-center gap-3 p-2 text-secondary font-black text-xl">
              <Phone className="w-5 h-5" /> (555) 999-0000
            </a>
            <LeadPopup>
              <Button className="w-full bg-secondary text-secondary-foreground py-6 text-lg rounded-none font-bold uppercase">
                GET EXPERT QUOTE
              </Button>
            </LeadPopup>
          </div>
        </div>
      )}
    </nav>
  );
}
