"use client";

import * as React from "react";
import { Star, Quote } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";

const testimonials = [
  {
    name: "James Chen",
    role: "Warehouse Manager",
    text: "KiriElectrics handled our entire warehouse lighting upgrade in record time. The precision in their wiring is exactly what we needed for a high-demand facility.",
    rating: 5,
    avatar: "https://picsum.photos/seed/kiri1/100/100"
  },
  {
    name: "Elena Rodriguez",
    role: "Tech Operations",
    text: "Reliability is everything for our server rooms. Kiri's team provided a backup power solution that has never failed us once during local outages.",
    rating: 5,
    avatar: "https://picsum.photos/seed/kiri2/100/100"
  },
  {
    name: "Marcus Thorne",
    role: "General Contractor",
    text: "I've worked with many electricians, but none have the professionalism and code-compliance knowledge that KiriElectrics brings to the site.",
    rating: 5,
    avatar: "https://picsum.photos/seed/kiri3/100/100"
  },
  {
    name: "Sarah Kim",
    role: "Retail Owner",
    text: "They transformed our boutique lighting. The attention to detail and the 'electric yellow' accents in their branding actually match their high-energy service!",
    rating: 5,
    avatar: "https://picsum.photos/seed/kiri4/100/100"
  }
];

export function Testimonials() {
  const plugin = React.useRef(
    Autoplay({ delay: 4000, stopOnInteraction: true })
  );

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-headline font-bold text-primary mb-4 uppercase tracking-tighter">Client Verdict</h2>
          <p className="text-muted-foreground text-lg">Engineered for success, trusted by leaders.</p>
        </div>
        
        <div className="max-w-5xl mx-auto px-12">
          <Carousel
            plugins={[plugin.current]}
            className="w-full"
            onMouseEnter={plugin.current.stop}
            onMouseLeave={plugin.current.reset}
          >
            <CarouselContent>
              {testimonials.map((t, idx) => (
                <CarouselItem key={idx} className="md:basis-1/2 lg:basis-1/3">
                  <Card className="h-full border-none shadow-none bg-accent/20 rounded-none relative">
                    <Quote className="absolute top-4 right-4 w-8 h-8 text-secondary/30" />
                    <CardContent className="p-8 flex flex-col h-full">
                      <div className="flex mb-4">
                        {[...Array(t.rating)].map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-secondary text-secondary" />
                        ))}
                      </div>
                      <p className="text-primary/90 italic mb-8 flex-grow leading-relaxed">"{t.text}"</p>
                      <div className="flex items-center gap-4 border-t border-primary/10 pt-6">
                        <Avatar className="h-12 w-12 border-2 border-secondary">
                          <AvatarImage src={t.avatar} alt={t.name} />
                          <AvatarFallback>{t.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-bold text-primary leading-none mb-1 text-sm uppercase">{t.name}</h4>
                          <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">{t.role}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground border-none" />
            <CarouselNext className="bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground border-none" />
          </Carousel>
        </div>
      </div>
    </section>
  );
}
