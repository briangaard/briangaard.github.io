import { config } from 'dotenv';
config();

import '@/ai/flows/ai-customer-service-recommender.ts';