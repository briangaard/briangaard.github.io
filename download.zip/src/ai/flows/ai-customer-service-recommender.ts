'use server';
/**
 * @fileOverview An AI-powered service recommender for KiriElectrics.
 *
 * - aiCustomerServiceRecommender - A function that guides users to the most suitable electrical service.
 * - ServiceRecommenderInput - The input type for the aiCustomerServiceRecommender function.
 * - ServiceRecommenderOutput - The return type for the aiCustomerServiceRecommender function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

/**
 * Defines the possible service categories KiriElectrics offers.
 */
const ServiceCategorySchema = z.enum([
  'Industrial Electrical Engineering',
  'Commercial Fit-outs & Maintenance',
  'Mission Critical Power Repairs',
  'Heavy Infrastructure Panels',
  'Smart Industrial Lighting',
  'Commercial EV Infrastructure',
  'Smart Factory Integration',
  'Compliance & Safety Inspections',
  'Emergency Power Troubleshooting',
  'Other',
  'Contact Form',
]);

const ServiceRecommenderInputSchema = z.object({
  conversationHistory: z.array(z.object({
    role: z.enum(['user', 'model']).describe('The role of the speaker (user or model).'),
    text: z.string().describe('The message content of the conversation turn.'),
  })).describe('Previous turns in the conversation to maintain context.'),
  currentQuery: z.string().describe('The user\'s latest input or question.'),
});
export type ServiceRecommenderInput = z.infer<typeof ServiceRecommenderInputSchema>;

const ServiceRecommenderOutputSchema = z.object({
  response: z.string().describe('The AI\'s response to the user.'),
  recommendedServiceCategory: ServiceCategorySchema.optional().describe('The specific service category recommended.'),
  isFinalRecommendation: z.boolean().describe('True if recommendation is final.'),
});
export type ServiceRecommenderOutput = z.infer<typeof ServiceRecommenderOutputSchema>;

export async function aiCustomerServiceRecommender(
  input: ServiceRecommenderInput
): Promise<ServiceRecommenderOutput> {
  return serviceRecommenderFlow(input);
}

const serviceRecommenderPrompt = ai.definePrompt({
  name: 'serviceRecommenderPrompt',
  input: { schema: ServiceRecommenderInputSchema },
  output: { schema: ServiceRecommenderOutputSchema },
  prompt: `You are an expert system advisor for KiriElectrics, an industrial and commercial electrical engineering firm. Your goal is to identify a client's technical needs and guide them to the right engineering category.

Available Categories:
- Industrial Electrical Engineering: For factories, plants, and heavy machinery.
- Commercial Fit-outs & Maintenance: For office buildings, retail malls, and hospitals.
- Mission Critical Power Repairs: For data centers, emergency rooms, and systems that cannot fail.
- Heavy Infrastructure Panels: For power distribution and high-voltage panel upgrades.
- Smart Industrial Lighting: For large scale LED and automated warehouse lighting.
- Commercial EV Infrastructure: For large scale charging stations for fleets or public use.
- Smart Factory Integration: For IoT, automation, and smart grid controls.
- Compliance & Safety Inspections: For code audits and insurance certifications.
- Emergency Power Troubleshooting: For immediate power failures and hazards.
- Contact Form: For complex bespoke engineering requests.

Instructions:
1. Act with high technical authority.
2. If enough info is present, recommend a category and set isFinalRecommendation to true.
3. If not, ask a precise technical question.
4. Your tone is professional, industrial, and efficient.

Conversation History:
{{#each conversationHistory}}
  {{#if (eq role "user")}}User: {{{text}}}
  {{else}}Kiri Advisor: {{{text}}}
  {{/if}}
{{/each}}

User's Query: {{{currentQuery}}}
`,
});

const serviceRecommenderFlow = ai.defineFlow(
  {
    name: 'serviceRecommenderFlow',
    inputSchema: ServiceRecommenderInputSchema,
    outputSchema: ServiceRecommenderOutputSchema,
  },
  async (input) => {
    const { output } = await serviceRecommenderPrompt(input);
    if (!output) {
      throw new Error('Technical failure in AI recommender.');
    }
    return output;
  }
);
