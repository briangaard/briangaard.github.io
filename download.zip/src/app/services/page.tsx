
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LeadPopup } from "@/components/LeadPopup";
import { Button } from "@/components/ui/button";
import { Home, Building2, Zap, Car, ShieldAlert, Thermometer, Wifi, Search } from "lucide-react";

export default function ServicesPage() {
  const serviceList = [
    { title: "Residential Wiring", icon: Home, desc: "New builds, renovations, and simple outlet fixes." },
    { title: "Commercial Systems", icon: Building2, desc: "Industrial-grade panels and energy-efficient lighting." },
    { title: "24/7 Emergency", icon: ShieldAlert, desc: "Fast response for critical power failures and hazards." },
    { title: "EV Charging", icon: Car, desc: "Home and business electric vehicle station installs." },
    { title: "Safety Inspections", icon: Search, desc: "Code compliance checks and pre-purchase surveys." },
    { title: "Smart Integration", icon: Wifi, desc: "Automated lighting and security system power." },
    { title: "Panel Upgrades", icon: Zap, desc: "Replacing outdated circuit breakers for modern safety." },
    { title: "HVAC Electrical", icon: Thermometer, desc: "Power solutions for climate control systems." },
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow pt-24 pb-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mb-16">
            <h1 className="text-4xl md:text-6xl font-headline font-bold text-primary mb-6">Expert Services for Every Need</h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Whether it's a flickering light in your kitchen or a multi-million dollar industrial facility, 
              we bring the same level of precision and expertise to every task.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {serviceList.map((service, i) => (
              <Card key={i} className="group hover:border-secondary transition-all">
                <CardHeader>
                  <div className="bg-secondary/10 w-12 h-12 rounded-xl flex items-center justify-center text-secondary mb-4 group-hover:bg-secondary group-hover:text-secondary-foreground transition-colors">
                    <service.icon className="w-6 h-6" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-6">{service.desc}</p>
                  <LeadPopup>
                    <Button variant="link" className="p-0 h-auto font-bold text-primary group-hover:text-secondary">Get Estimate →</Button>
                  </LeadPopup>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-24 p-12 bg-white rounded-3xl border text-center max-w-4xl mx-auto shadow-sm">
            <h2 className="text-2xl font-headline font-bold text-primary mb-4">Can't see what you're looking for?</h2>
            <p className="text-muted-foreground mb-8">
              This is just a highlight of our main offerings. We are fully equipped for almost any electrical project imaginable.
            </p>
            <LeadPopup>
              <Button className="bg-primary hover:bg-primary/90 px-8 py-6">Inquire About Custom Project</Button>
            </LeadPopup>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
