import Image from "next/image";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Testimonials } from "@/components/Testimonials";
import { AIRecommender } from "@/components/AIRecommender";
import { LeadPopup } from "@/components/LeadPopup";
import { Button } from "@/components/ui/button";
import { Zap, ShieldCheck, Clock, Award, CheckCircle2, ArrowRight, Lightbulb, Home as HomeIcon, PhoneCall } from "lucide-react";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Link from "next/link";

export default function Home() {
  const heroImg = PlaceHolderImages.find(img => img.id === "hero-bg");

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative pt-24 pb-32 md:pt-40 md:pb-48 overflow-hidden bg-primary">
          <div className="absolute inset-0 z-0">
            <Image 
              src={heroImg?.imageUrl || ""} 
              alt="Industrial Circuitry and Lightning" 
              fill 
              className="object-cover opacity-30 grayscale"
              data-ai-hint="circuitry electricity"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary via-primary/70 to-transparent"></div>
          </div>
          
          <div className="container mx-auto px-4 relative z-10 text-center md:text-left">
            <div className="max-w-4xl">
              <div className="inline-flex items-center gap-2 bg-secondary text-secondary-foreground px-4 py-2 rounded-none font-black text-xs mb-8 uppercase tracking-[0.3em] animate-pulse">
                <Zap className="w-4 h-4 fill-current" /> EMERGENCY RESPONSE: 24/7 ACTIVE
              </div>
              <h1 className="text-5xl md:text-8xl font-headline font-bold text-white mb-8 leading-[0.9] tracking-tighter uppercase">
                CRITICAL <br /><span className="text-secondary italic">POWER</span> <br />SOLUTIONS.
              </h1>
              <p className="text-lg md:text-2xl text-white/80 max-w-2xl mb-12 leading-tight font-medium uppercase tracking-wide">
                When failure is not an option, KiriElectrics delivers. High-voltage engineering for industrial giants.
              </p>
              <div className="flex flex-col sm:flex-row gap-6 justify-center md:justify-start">
                <LeadPopup>
                  <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90 text-xl px-12 py-10 rounded-none font-black uppercase tracking-[0.15em] shadow-[0_10px_50px_rgba(255,215,0,0.3)] border-none">
                    DIAGNOSE MY SYSTEM <ArrowRight className="ml-3 w-6 h-6" />
                  </Button>
                </LeadPopup>
                <Button size="lg" variant="outline" className="bg-white text-primary border-none hover:bg-white/90 rounded-none text-xl px-12 py-10 uppercase tracking-[0.15em] font-black transition-all shadow-xl" asChild>
                  <Link href="tel:5559990000">
                    <PhoneCall className="mr-2 w-6 h-6" /> CALL AN ENGINEER
                  </Link>
                </Button>
              </div>
            </div>
            
            <div className="mt-20 flex flex-wrap justify-center md:justify-start gap-12 text-white/60 uppercase text-xs font-black tracking-[0.25em]">
              <div className="flex items-center gap-4"><CheckCircle2 className="w-4 h-4 text-secondary" /> ZERO DOWNTIME GUARANTEE</div>
              <div className="flex items-center gap-4"><CheckCircle2 className="w-4 h-4 text-secondary" /> RAPID SITE DEPLOYMENT</div>
              <div className="flex items-center gap-4"><CheckCircle2 className="w-4 h-4 text-secondary" /> MASTER INDUSTRIAL LICENSED</div>
            </div>
          </div>
        </section>

        {/* Dashboard Shortcut Section */}
        <section className="bg-secondary py-6 border-y-4 border-primary">
          <div className="container mx-auto px-4 flex justify-center">
            <Button variant="ghost" className="text-secondary-foreground font-black uppercase tracking-[0.2em] text-xs hover:bg-primary hover:text-secondary group py-6 px-10" asChild>
              <Link href="/">
                <HomeIcon className="mr-3 w-5 h-5 group-hover:scale-125 transition-transform" /> PROJECT DASHBOARD
              </Link>
            </Button>
          </div>
        </section>

        {/* Capabilities Section */}
        <section className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-px bg-border border-4 border-primary shadow-2xl">
              {[
                { icon: ShieldCheck, title: "Mission Critical", desc: "Redundant power systems designed for data centers and hospitals." },
                { icon: Clock, title: "Rapid Recovery", desc: "Instant response team for industrial grid failures and hazardous outages." },
                { icon: Award, title: "Precision Load", desc: "Expert load balancing for heavy machinery and manufacturing plants." },
                { icon: Lightbulb, title: "Grid Efficiency", desc: "Next-gen energy monitoring to slash industrial consumption overhead." }
              ].map((benefit, i) => (
                <div key={i} className="bg-white p-10 hover:bg-secondary/10 transition-all duration-300 border-r border-border last:border-r-0 group">
                  <div className="bg-primary text-secondary w-14 h-14 flex items-center justify-center mb-8 group-hover:scale-110 transition-transform">
                    <benefit.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-black text-primary mb-5 uppercase tracking-tight leading-none">{benefit.title}</h3>
                  <p className="text-muted-foreground leading-relaxed font-bold uppercase text-[11px] tracking-wider">{benefit.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Reviews Section */}
        <Testimonials />

        {/* AI System Diagnosis */}
        <section className="py-24 bg-primary text-white border-y-[12px] border-secondary">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row gap-16 items-center">
              <div className="div lg:w-1/2">
                <div className="bg-secondary text-primary inline-block px-4 py-1 mb-8 font-black text-xs uppercase tracking-widest">ADVANCED AI UNIT</div>
                <h2 className="text-4xl md:text-6xl font-headline font-bold mb-8 tracking-tighter uppercase leading-[0.9]">
                  IS YOUR SYSTEM <span className="text-secondary">FAILING?</span>
                </h2>
                <p className="text-white/70 text-lg mb-12 leading-relaxed font-medium">
                  Input your system symptoms. Our AI engine analyzes industrial fault patterns to recommend immediate technical intervention or category assignment.
                </p>
                <div className="grid grid-cols-2 gap-8">
                  <div className="border-l-4 border-secondary pl-6">
                    <div className="text-3xl font-black text-white mb-2">0.4s</div>
                    <div className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">Response Time</div>
                  </div>
                  <div className="border-l-4 border-secondary pl-6">
                    <div className="text-3xl font-black text-white mb-2">100%</div>
                    <div className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">Technical Accuracy</div>
                  </div>
                </div>
              </div>
              <div className="lg:w-1/2 w-full">
                <AIRecommender />
              </div>
            </div>
          </div>
        </section>

        {/* Massive Call to Action */}
        <section className="py-32 bg-secondary relative overflow-hidden">
          <div className="absolute top-0 right-0 opacity-10">
             <Zap className="w-[600px] h-[600px] -mr-32 -mt-32 text-primary" />
          </div>
          <div className="container mx-auto px-4 text-center relative z-10">
            <h2 className="text-5xl md:text-7xl font-headline font-bold text-primary mb-10 tracking-tighter uppercase leading-none">
              GRID OFFLINE? <br /><span className="bg-primary text-white px-4 py-1 text-4xl md:text-6xl">CALL NOW.</span>
            </h2>
            <p className="text-primary/80 text-xl max-w-3xl mx-auto mb-14 font-black uppercase tracking-[0.25em]">
              DON'T RISK YOUR REVENUE ON STANDARD SERVICE. DEMAND KIRI PERFORMANCE.
            </p>
            <div className="flex flex-col sm:flex-row gap-10 justify-center items-center">
              <LeadPopup>
                <Button className="bg-primary text-white hover:bg-primary/90 px-14 py-10 text-xl font-black uppercase tracking-[0.25em] rounded-none shadow-[0_20px_60px_rgba(0,0,0,0.4)] border-none">
                  INITIATE MISSION
                </Button>
              </LeadPopup>
              <a href="tel:5559990000" className="inline-flex items-center justify-center gap-4 text-primary font-headline font-bold text-4xl hover:scale-105 transition-all group">
                <PhoneCall className="w-10 h-10 group-hover:rotate-12 transition-transform" /> (555) 999-0000
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
