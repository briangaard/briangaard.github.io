
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Award, ShieldCheck, Users, Clock } from "lucide-react";

export default function AboutPage() {
  const aboutImg = PlaceHolderImages.find(img => img.id === "about-team");

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow pt-24 pb-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-32">
            <div>
              <div className="inline-block bg-secondary text-secondary-foreground px-4 py-1.5 rounded-full font-bold text-xs uppercase mb-6">Our Legacy</div>
              <h1 className="text-4xl md:text-6xl font-headline font-bold text-primary mb-8 leading-tight">Mastering Electricity Since 2005</h1>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                VoltBoost Electrics was founded on a simple principle: doing the job right the first time. 
                What started as a one-man operation has grown into the region's most trusted name in electrical precision.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Today, our team of certified master electricians serves thousands of families and businesses, 
                combining old-school reliability with modern smart-home innovation.
              </p>
            </div>
            <div className="relative h-[500px] rounded-3xl overflow-hidden shadow-2xl">
              <Image 
                src={aboutImg?.imageUrl || ""} 
                alt="Our Team" 
                fill 
                className="object-cover" 
                data-ai-hint="professional team"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 text-center">
            {[
              { icon: Award, label: "Master Electricians", val: "15+" },
              { icon: Users, label: "Happy Clients", val: "5,000+" },
              { icon: ShieldCheck, label: "Safety Rating", val: "100%" },
              { icon: Clock, label: "Years Experience", val: "18" }
            ].map((stat, i) => (
              <div key={i}>
                <div className="inline-flex items-center justify-center w-16 h-16 bg-accent rounded-2xl mb-6 text-primary">
                  <stat.icon className="w-8 h-8" />
                </div>
                <div className="text-4xl font-headline font-bold text-primary mb-2">{stat.val}</div>
                <div className="text-muted-foreground font-medium uppercase text-xs tracking-widest">{stat.label}</div>
              </div>
            ))}
          </div>

          <div className="mt-32 p-12 bg-primary rounded-3xl text-primary-foreground text-center">
            <h2 className="text-3xl font-headline font-bold mb-6">Our Commitment to You</h2>
            <p className="max-w-2xl mx-auto text-primary-foreground/70 text-lg leading-relaxed">
              We treat every home like it's our own and every business like our livelihood depends on it. 
              Our technicians are not just workers; they are precision experts dedicated to your safety.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
